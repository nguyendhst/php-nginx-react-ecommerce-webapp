module.exports = {
  verbose: true,
  setupFiles: ['./__tests__/setup.js'],
  testPathIgnorePatterns: ['__tests__/setup*.js'],
};
